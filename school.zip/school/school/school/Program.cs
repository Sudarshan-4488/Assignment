﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using System.Data.SqlClient;

namespace school
{
    class Program
    {
       

        static void Main(string[] args)
        {
            

            Console.WriteLine("*******************************");
            Tec1 t = new Tec1();
        start: Console.Write("Select Options from:\n 1:To Add Teacher\n 2:Get All Teachers\n===============================\n");

            int choice = int.Parse(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    Console.Write("Enter Teacher Id:");
                    int id = int.Parse(Console.ReadLine());
                    Console.Write("Enter Teachers Name:");
                    string name = Console.ReadLine();
                    Console.Write("Enter Teachers class:");
                    int clss = int.Parse(Console.ReadLine());
                    Console.Write("Enter Teachers Sec:");
                    string sec = Console.ReadLine();
                    var newTeacher = new Teacher { Id = id, Name = name, Clss = clss, Sec = sec };
                    t.Add(newTeacher);
                    StreamWriter w = null;
                    w = File.CreateText(@"C:\Users\Sudarshan\source\repos\school\school\school\TeachersData.txt");

                    var data = (newTeacher.Id, newTeacher.Name, newTeacher.Clss, newTeacher.Sec);
                   
                    w.Write(Convert.ToString(data));
                    
                    
                    Console.WriteLine(name + " is added successfully...\n===============================\n");
                    w.Close();
                    break;
                case 2:
                    
                    var allTeachers = t.GetAllTeachers();
                    foreach (var teacher in allTeachers)
                    {
                        Console.WriteLine($"{teacher.Id}\t{teacher.Name}\t{teacher.Clss}\t{teacher.Sec}");
                    }
                    Console.Write("\n===============================\n");
                    break;
            }
            Console.Write("Do you want to continue (yes/no)?:");
            string response = Console.ReadLine();
            if (response.ToLowerInvariant() == "y")
            {
                goto start;
            }
            Console.ReadLine();

        }
    }
}
