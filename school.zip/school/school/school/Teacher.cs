﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace school
{
    class Teacher
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public int Clss { get; set; }
        public string Sec { get; set; }
    }
}
