﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace school
{
    class Tec1:Mytc
    {
        public static List<Teacher> tec1 = new List<Teacher>();
        public Tec1()
        { 
            tec1.Capacity = 100;
        }
        public void Add(Teacher teacher)
        {
            if (tec1.Count < 11)
            {
                tec1.Add(teacher);
            }
        }
        public List<Teacher>GetAllTeachers()
        {
            return tec1.ToList();
        }
    }
}
